#!/usr/bin/perl5
#
# pnpsoftcart.pl
# copyright Plug and Pay Technologies, Inc. 1999,2000,2001
# The purpose of this script is to allow the Plug & Pay Payment System
# to be utilized with the Softcart shopping cart program.
#
# Edit first line to reflect location of PERL 5.
require 5.001;

use pnpremote;

#$mode = "debug";
$path_debug_file = "pnpdebug.txt";

################  Do Not Edit Below this Line ##########################

while (<STDIN>) {
  chop;
  my ($key,$value) = split('\t');
  $key =~ s/[^a-zA-Z0-9_\.\/\@:\-\~\?\&\=]//g;
  $value =~ s/[^a-zA-Z0-9_\.\/\@:\-\~\?\&\=\ ]//g;
  $query{$key} = $value;
}

open(CONFIG,$query{'config'}) || &return_error_response("Cannot Open Configuration File $|=1");
while(<CONFIG>) {
  chop;
  if ((substr($_,0,1) ne "\;") && (substr($_,0,1) ne "\#") && ($_ ne "")) {
    my ($key,$value) = split('\t');
    $key =~ s/[^a-zA-Z0-9_\.\/\@:\-\~\?\&\=]//g;
    $value =~ s/[^a-zA-Z0-9_\.\/\@:\-\~\?\&\=\ ]//g;
    $query{$key} = $value;
  }
}
close(CONFIG);

$query{'order-id'} = $query{'orderid'};
$query{'easycart'} = "1";

@array = %query;
$payment = pnpremote->new(@array);
$payment->luhn10($query{'card-number'});

if ($pnpremote::query{'FinalStatus'} ne "badcard") {
  $payment->purchase();
}

if ($mode eq "debug") {
  open (DEBUG,">$path_debug_file");
  foreach $key (sort keys %pnpremote::query) {
    print DEBUG "$key:$pnpremote::query{$key}, ";
  }
  print DEBUG "\n";
  close(DEBUG);
}

&return_response();

exit;

sub return_response {
  print "approved\t$pnpremote::query{'success'}\n";
  print "error\t$pnpremote::query{'MErrMsg'}\n";
  printf("authnumber\t%s\n", $pnpremote::query{'auth-code'});
  printf("transactionnumber\t%s\n", $query{'orderID'});
}

sub return_error_response {
  my ($error) = @_;
  print "approved\tno\n";
  print "error\t$error\n";
}