This is the README file for the Plugnpay Payment Solution
for Mercantec's Softcart for PERL. 

Copyright Plugnpay Technology Inc. 2000,2001

Included with this README are the following:

	pnpsoftcart.pl
		The Plugnpay Application.

	pnpsoftcart.cfg
		The config file for use by the Plugnpay Application.  

	pnpsoftcart.tpl
		A template file used by Softcart.


Instructions:

	Step 1. Once the file is unzipped, copy or move all of the 
		files to the cgi-bin directory where Softcart
		resides.  The files are:
			pnpsoftcart.tpl
			pnpsftcrt.pl
			pnpsoftcart.cfg

	Step 2. Open the file pnpsoftcart.cfg with a text editor 
		(ex. Notepad).  Change the "publisher-email" to 
		where ever you need the confirmation email from 
		Plugnpay to be sent.  Now change the "publisher-name"
		to your Plugnpay username.

		ex:
		publisher-name	myusername
		publisher-email	me@myserver.com


		**Note**When setting the fields.  Please separate
			them with a tab.  DO NOT USE SPACES.

			ex: publisher-name<tab>myusername 

		When done, save the file.  Make sure you
		save it to the correct directory.  It should
		be in the cgi-bin directory.

		You can also comment lines out.  That is, allow
		you to place extra lines in the file without
		the Plugnpay Application reading it.  To do this,
		just place a semi-colon (;) at the begining of any
		line.  Comments can only be used on a per line
		basis.

	Step 3. Open your store config file.  This file is made by 
		the Softcart installation.  It should be named the
		same as your store.  With Softcart, the default
		might be called "scstore.cfg".  Once this is opened,
		you must place the following three lines in that
		file.
		
			CCAuthProgram	./cgi-bin/pnpsftcrt.pl
			CCAuthConfig	./cgi-bin/pnpsoftcart.cfg
			CCAuthTemplate	./cgi-bin/pnpsoftcart.tpl

		when placing these lines, please remember to use a 
		tab and not spaces.  

            **NOTE** If there are already similar lines in the file
			 pointing to another processor, like CyberCash, these
                   lines must be commented out or deleted.

		**Note** The paths used in the examples should be 
			 replaced with the actual path to your 
			 cgi-bin directory.  On some systems relative 
                   paths work OK.  On others, absolute paths are 
                   required. If the program does not appear to be 
                   working properly you may wish to switch from 
                   absolute to relative or vice versa.  Please be 
                   careful with copying and pasting.  It could 
			 replace the tabs with spaces by accident.
			 Please be sure that there are tabs 
			 separating the key words from the paths
			 and not spaces.

		 When done editing, save this file.  Again, make sure 
		 you save it in your cgi-bin directory.

	Step 4. Both SoftCart and PlugnPay have the ability to send out 
		emails to both the customer and/or you the merchant.
                By default, PlugnPay will send out emails to both of these
		emails.  To disable PlugnPay from sending one or both of these
		emails, edit the file pnpsoftcart.cfg as noted in the comments 
		included in the file.
           
		If you wish to use PlugnPay's email system and disable the system in 
		SoftCart, you need to located the line in the store config file, 
		scstore.cfg by default, containing the string "rcptmail.exe" and 
		comment out this line by placing a semi-colon in front of it.
                